package com.he.addressBook;

import java.util.List;

public class AddressBook {

    public AddressBook() {
        //TODO
    }

    public void addContact(Contact contact) {
        //TODO
    }

    public void deleteContact(String name) {
        //TODO
    }

    public void updateContact(String name, Contact contact) {
        //TODO
    }

    public List<Contact> searchByName(String name) {
        //TODO
        return null;
    }

    public List<Contact> searchByOrganisation(String organisation) {
        //TODO
        return null;
    }

}